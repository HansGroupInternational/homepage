Flappy Bird Clone for Graphing Calculator by Ameobea

Installation Instructions:  
Take the programs BIRDY and RUNBIRD and use some kind of linking program to send them to the calculator.  The most popular linking software is called TI-Connect and is linked below:

http://education.ti.com/en/us/products/computer_software/connectivity-software/ti-connect-software/features/features-summary

Once you have them on the calculator, you can run the program by simply running the program RUNBIRD found in your programs directory which can be accessed by pressing the PRGM button on your calculator.  Program BIRDY is the unassembled version of the game, and cannot be run as-is.  However, both programs must be kept in the program directory in order to play the game.

Gameplay:
If you're unfamiliar with flappy bird, and even if you are familiar, the general idea is very simple: You have to keep the bird (in this case a small dot) in between the lines of the pipes as the screen scrolls.  To "flap" the bird, use the enter key.  This will propel the bird upwards with a given momentum.  

As soon as the program executes, the bird starts to fall, so you'll have to press the enter button rapidly in order to keep it from falling immediately.  Continue pressing enter as often as necessary to keep the bird level with the pipes.  

If you hit a wall or press the DEL button at any time during the game, the game will immediatly exit and display your score on the main screen.  

Notes:  This game was made by a highschool student during his not-so-spare time aka calc class.  It's provided as-is, and yes it sucks but I know I've had fun with it, as well as my friends.  If you have any questions about the game, message me on Reddit (Username Ameobea)

Redistribution of this game is not allowed.  If you want to give it to some friends, fine.  But PLEASE don't post this online and claim it as your own or even claim it as mine.  This took time and energy to make!


Most importantly, THANK YOU for downloading this game!  I REALLY hope you enjoy it!  Leave ANY comments, questions, or feedback as messages to me on reddit (Username Ameobea) and I will reply ASAP!  

P.S. My hiscore is 42 - see if you can beat it ;)
